-- ============================================
-- INIT: Create schemas and raw tables
-- ============================================
-- This script is run automatically on PostgreSQL container startup

-- Create schemas
CREATE SCHEMA IF NOT EXISTS raw;
CREATE SCHEMA IF NOT EXISTS staging;
CREATE SCHEMA IF NOT EXISTS mart;

-- ============================================
-- RAW TABLES
-- ============================================

-- Raw Orders
CREATE TABLE IF NOT EXISTS raw.raw_orders (
    order_id VARCHAR(50),
    customer_id VARCHAR(50),
    product_id VARCHAR(50),
    quantity INTEGER,
    unit_price DECIMAL(10, 2),
    total_amount DECIMAL(12, 2),
    order_date VARCHAR(50),
    order_status VARCHAR(50),
    shipping_address TEXT,
    -- Metadata columns
    _loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    _source_file VARCHAR(255),
    _execution_date DATE
);

-- Raw Customers
CREATE TABLE IF NOT EXISTS raw.raw_customers (
    customer_id VARCHAR(50),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100),
    created_at VARCHAR(50),
    -- Metadata columns
    _loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    _source_file VARCHAR(255),
    _execution_date DATE
);

-- Raw Products
CREATE TABLE IF NOT EXISTS raw.raw_products (
    product_id VARCHAR(50),
    product_name VARCHAR(255),
    category VARCHAR(100),
    subcategory VARCHAR(100),
    price DECIMAL(10, 2),
    cost DECIMAL(10, 2),
    stock_quantity INTEGER,
    supplier VARCHAR(255),
    -- Metadata columns
    _loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    _source_file VARCHAR(255),
    _execution_date DATE
);

-- Raw Payments
CREATE TABLE IF NOT EXISTS raw.raw_payments (
    payment_id VARCHAR(50),
    order_id VARCHAR(50),
    payment_method VARCHAR(50),
    payment_amount DECIMAL(12, 2),
    payment_date VARCHAR(50),
    payment_status VARCHAR(50),
    -- Metadata columns
    _loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    _source_file VARCHAR(255),
    _execution_date DATE
);

-- ============================================
-- STAGING TABLES
-- ============================================

-- Staging Orders
CREATE TABLE IF NOT EXISTS staging.stg_orders (
    order_id INTEGER PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(12, 2) NOT NULL,
    order_date DATE NOT NULL,
    order_status VARCHAR(50),
    shipping_address TEXT,
    _loaded_at TIMESTAMP,
    _execution_date DATE
);

-- Staging Customers
CREATE TABLE IF NOT EXISTS staging.stg_customers (
    customer_id INTEGER PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    full_name VARCHAR(200),
    email VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100),
    created_at DATE,
    _loaded_at TIMESTAMP,
    _execution_date DATE
);

-- Staging Products
CREATE TABLE IF NOT EXISTS staging.stg_products (
    product_id INTEGER PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    subcategory VARCHAR(100),
    price DECIMAL(10, 2) NOT NULL,
    cost DECIMAL(10, 2),
    margin DECIMAL(10, 2),
    margin_pct DECIMAL(5, 2),
    stock_quantity INTEGER,
    supplier VARCHAR(255),
    _loaded_at TIMESTAMP,
    _execution_date DATE
);

-- Staging Payments
CREATE TABLE IF NOT EXISTS staging.stg_payments (
    payment_id INTEGER PRIMARY KEY,
    order_id INTEGER NOT NULL,
    payment_method VARCHAR(50),
    payment_amount DECIMAL(12, 2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_status VARCHAR(50),
    _loaded_at TIMESTAMP,
    _execution_date DATE
);

-- ============================================
-- MART TABLES
-- ============================================

-- Revenue Daily
CREATE TABLE IF NOT EXISTS mart.revenue_daily (
    order_date DATE PRIMARY KEY,
    total_orders INTEGER,
    total_quantity INTEGER,
    total_revenue DECIMAL(14, 2),
    average_order_value DECIMAL(10, 2),
    _updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Top Products
CREATE TABLE IF NOT EXISTS mart.top_products (
    product_id INTEGER,
    product_name VARCHAR(255),
    category VARCHAR(100),
    total_quantity INTEGER,
    total_revenue DECIMAL(14, 2),
    order_count INTEGER,
    rank INTEGER,
    period_start DATE,
    period_end DATE,
    _updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (product_id, period_start)
);

-- Customer LTV
CREATE TABLE IF NOT EXISTS mart.customer_ltv (
    customer_id INTEGER PRIMARY KEY,
    full_name VARCHAR(200),
    email VARCHAR(255),
    first_order_date DATE,
    last_order_date DATE,
    total_orders INTEGER,
    total_quantity INTEGER,
    lifetime_value DECIMAL(14, 2),
    average_order_value DECIMAL(10, 2),
    customer_tenure_days INTEGER,
    _updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- INDEXES
-- ============================================

-- Raw tables indexes
CREATE INDEX IF NOT EXISTS idx_raw_orders_date ON raw.raw_orders(_execution_date);
CREATE INDEX IF NOT EXISTS idx_raw_customers_date ON raw.raw_customers(_execution_date);
CREATE INDEX IF NOT EXISTS idx_raw_products_date ON raw.raw_products(_execution_date);
CREATE INDEX IF NOT EXISTS idx_raw_payments_date ON raw.raw_payments(_execution_date);

-- Staging tables indexes
CREATE INDEX IF NOT EXISTS idx_stg_orders_customer ON staging.stg_orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_stg_orders_product ON staging.stg_orders(product_id);
CREATE INDEX IF NOT EXISTS idx_stg_orders_date ON staging.stg_orders(order_date);
CREATE INDEX IF NOT EXISTS idx_stg_payments_order ON staging.stg_payments(order_id);

-- Grant permissions
GRANT ALL ON SCHEMA raw TO airflow;
GRANT ALL ON SCHEMA staging TO airflow;
GRANT ALL ON SCHEMA mart TO airflow;
GRANT ALL ON ALL TABLES IN SCHEMA raw TO airflow;
GRANT ALL ON ALL TABLES IN SCHEMA staging TO airflow;
GRANT ALL ON ALL TABLES IN SCHEMA mart TO airflow;
