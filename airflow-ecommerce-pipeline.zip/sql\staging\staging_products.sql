-- ============================================
-- STAGING: Products
-- ============================================
-- Clean, type, and deduplicate products from raw layer
-- Idempotent: TRUNCATE + INSERT pattern

-- Truncate staging table for idempotence
TRUNCATE TABLE staging.stg_products;

-- Insert cleaned and typed data
INSERT INTO staging.stg_products (
    product_id,
    product_name,
    category,
    subcategory,
    price,
    cost,
    margin,
    margin_pct,
    stock_quantity,
    supplier,
    _loaded_at,
    _execution_date
)
SELECT DISTINCT ON (CAST(product_id AS INTEGER))
    -- Type conversions
    CAST(product_id AS INTEGER) AS product_id,
    -- Clean product name
    TRIM(COALESCE(product_name, 'Unknown Product')) AS product_name,
    -- Normalize categories
    INITCAP(TRIM(COALESCE(category, 'Uncategorized'))) AS category,
    INITCAP(TRIM(subcategory)) AS subcategory,
    -- Prices
    COALESCE(price, 0) AS price,
    COALESCE(cost, 0) AS cost,
    -- Calculate margin
    COALESCE(price, 0) - COALESCE(cost, 0) AS margin,
    -- Calculate margin percentage (avoid division by zero)
    CASE
        WHEN COALESCE(price, 0) > 0
        THEN ROUND(
            ((COALESCE(price, 0) - COALESCE(cost, 0)) / COALESCE(price, 1)) * 100,
            2
        )
        ELSE 0
    END AS margin_pct,
    -- Stock
    GREATEST(COALESCE(stock_quantity, 0), 0) AS stock_quantity,
    TRIM(supplier) AS supplier,
    _loaded_at,
    _execution_date
FROM raw.raw_products
WHERE
    -- Filter valid records
    product_id IS NOT NULL
    -- Price must be non-negative
    AND COALESCE(price, 0) >= 0
ORDER BY
    CAST(product_id AS INTEGER),
    _loaded_at DESC  -- Keep most recent in case of duplicates
;

-- Log row count
DO $$
BEGIN
    RAISE NOTICE 'Staging products loaded: % rows',
        (SELECT COUNT(*) FROM staging.stg_products);
END $$;
