-- ============================================
-- STAGING: Customers
-- ============================================
-- Clean, type, and deduplicate customers from raw layer
-- Idempotent: TRUNCATE + INSERT pattern

-- Truncate staging table for idempotence
TRUNCATE TABLE staging.stg_customers;

-- Insert cleaned and typed data
INSERT INTO staging.stg_customers (
    customer_id,
    first_name,
    last_name,
    full_name,
    email,
    phone,
    address,
    city,
    country,
    created_at,
    _loaded_at,
    _execution_date
)
SELECT DISTINCT ON (CAST(customer_id AS INTEGER))
    -- Type conversions
    CAST(customer_id AS INTEGER) AS customer_id,
    -- Clean names
    INITCAP(TRIM(COALESCE(first_name, ''))) AS first_name,
    INITCAP(TRIM(COALESCE(last_name, ''))) AS last_name,
    -- Create full name
    TRIM(
        INITCAP(COALESCE(first_name, '')) || ' ' ||
        INITCAP(COALESCE(last_name, ''))
    ) AS full_name,
    -- Normalize email
    LOWER(TRIM(email)) AS email,
    -- Clean phone (remove non-digits except +)
    REGEXP_REPLACE(phone, '[^0-9+]', '', 'g') AS phone,
    TRIM(address) AS address,
    INITCAP(TRIM(city)) AS city,
    UPPER(TRIM(COALESCE(country, 'UNKNOWN'))) AS country,
    -- Parse date
    CASE
        WHEN created_at ~ '^\d{4}-\d{2}-\d{2}' THEN CAST(created_at AS DATE)
        WHEN created_at ~ '^\d{2}/\d{2}/\d{4}' THEN TO_DATE(created_at, 'DD/MM/YYYY')
        ELSE CURRENT_DATE
    END AS created_at,
    _loaded_at,
    _execution_date
FROM raw.raw_customers
WHERE
    -- Filter valid records
    customer_id IS NOT NULL
    -- Email validation (basic)
    AND (email IS NULL OR email LIKE '%@%.%')
ORDER BY
    CAST(customer_id AS INTEGER),
    _loaded_at DESC  -- Keep most recent in case of duplicates
;

-- Log row count
DO $$
BEGIN
    RAISE NOTICE 'Staging customers loaded: % rows',
        (SELECT COUNT(*) FROM staging.stg_customers);
END $$;
