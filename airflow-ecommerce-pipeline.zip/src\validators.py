"""
Validators Module

Schema validation and data quality checks for CSV files.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)


# Expected schemas for each entity
EXPECTED_SCHEMAS: dict[str, dict[str, Any]] = {
    "orders": {
        "required_columns": [
            "order_id",
            "customer_id",
            "product_id",
            "quantity",
            "unit_price",
            "total_amount",
            "order_date",
            "order_status",
        ],
        "optional_columns": ["shipping_address"],
        "types": {
            "order_id": ["int64", "object"],
            "customer_id": ["int64", "object"],
            "product_id": ["int64", "object"],
            "quantity": ["int64"],
            "unit_price": ["float64"],
            "total_amount": ["float64"],
            "order_date": ["object", "datetime64[ns]"],
            "order_status": ["object"],
        },
    },
    "customers": {
        "required_columns": [
            "customer_id",
            "first_name",
            "last_name",
            "email",
        ],
        "optional_columns": [
            "phone",
            "address",
            "city",
            "country",
            "created_at",
        ],
        "types": {
            "customer_id": ["int64", "object"],
            "first_name": ["object"],
            "last_name": ["object"],
            "email": ["object"],
        },
    },
    "products": {
        "required_columns": [
            "product_id",
            "product_name",
            "category",
            "price",
        ],
        "optional_columns": [
            "subcategory",
            "cost",
            "stock_quantity",
            "supplier",
        ],
        "types": {
            "product_id": ["int64", "object"],
            "product_name": ["object"],
            "category": ["object"],
            "price": ["float64", "int64"],
        },
    },
    "payments": {
        "required_columns": [
            "payment_id",
            "order_id",
            "payment_method",
            "payment_amount",
            "payment_date",
            "payment_status",
        ],
        "optional_columns": [],
        "types": {
            "payment_id": ["int64", "object"],
            "order_id": ["int64", "object"],
            "payment_method": ["object"],
            "payment_amount": ["float64"],
            "payment_date": ["object", "datetime64[ns]"],
            "payment_status": ["object"],
        },
    },
}


def validate_csv_schema(
    file_path: str | Path,
    schema: dict[str, Any],
) -> tuple[bool, list[str]]:
    """
    Validate a CSV file against an expected schema.

    Args:
        file_path: Path to CSV file
        schema: Expected schema dictionary with:
            - required_columns: list of required column names
            - optional_columns: list of optional column names
            - types: dict of column name -> list of acceptable dtypes

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    file_path = Path(file_path)
    errors: list[str] = []

    # Check file exists
    if not file_path.exists():
        errors.append(f"File not found: {file_path}")
        return False, errors

    # Read CSV
    try:
        df = pd.read_csv(file_path, nrows=100)  # Read sample for validation
    except Exception as e:
        errors.append(f"Error reading CSV: {e}")
        return False, errors

    # Check for empty file
    if len(df) == 0:
        errors.append("CSV file is empty")
        return False, errors

    actual_columns = set(df.columns)
    required_columns = set(schema.get("required_columns", []))
    optional_columns = set(schema.get("optional_columns", []))
    type_specs = schema.get("types", {})

    # Check required columns
    missing_columns = required_columns - actual_columns
    if missing_columns:
        errors.append(f"Missing required columns: {missing_columns}")

    # Check for unexpected columns (warning only)
    expected_all = required_columns | optional_columns
    extra_columns = actual_columns - expected_all
    if extra_columns:
        logger.warning(f"Unexpected columns (will be ignored): {extra_columns}")

    # Validate column types
    for col, expected_types in type_specs.items():
        if col in actual_columns:
            actual_type = str(df[col].dtype)
            if actual_type not in expected_types:
                errors.append(
                    f"Column '{col}' has type '{actual_type}', "
                    f"expected one of: {expected_types}"
                )

    is_valid = len(errors) == 0
    return is_valid, errors


def validate_not_null(
    df: pd.DataFrame,
    columns: list[str],
) -> tuple[bool, list[str]]:
    """
    Validate that specified columns have no null values.

    Args:
        df: DataFrame to validate
        columns: List of column names to check

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors: list[str] = []

    for col in columns:
        if col not in df.columns:
            errors.append(f"Column '{col}' not found in DataFrame")
            continue

        null_count = df[col].isnull().sum()
        if null_count > 0:
            errors.append(f"Column '{col}' has {null_count} null values")

    is_valid = len(errors) == 0
    return is_valid, errors


def validate_positive_values(
    df: pd.DataFrame,
    columns: list[str],
) -> tuple[bool, list[str]]:
    """
    Validate that specified numeric columns have non-negative values.

    Args:
        df: DataFrame to validate
        columns: List of column names to check

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors: list[str] = []

    for col in columns:
        if col not in df.columns:
            errors.append(f"Column '{col}' not found in DataFrame")
            continue

        negative_count = (df[col] < 0).sum()
        if negative_count > 0:
            errors.append(f"Column '{col}' has {negative_count} negative values")

    is_valid = len(errors) == 0
    return is_valid, errors


def validate_date_range(
    df: pd.DataFrame,
    date_column: str,
    min_date: str | None = None,
    max_date: str | None = None,
) -> tuple[bool, list[str]]:
    """
    Validate that dates are within an expected range.

    Args:
        df: DataFrame to validate
        date_column: Name of date column
        min_date: Minimum allowed date (ISO format)
        max_date: Maximum allowed date (ISO format)

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors: list[str] = []

    if date_column not in df.columns:
        errors.append(f"Column '{date_column}' not found in DataFrame")
        return False, errors

    # Parse dates
    try:
        dates = pd.to_datetime(df[date_column], errors="coerce")
    except Exception as e:
        errors.append(f"Error parsing dates in '{date_column}': {e}")
        return False, errors

    # Check for unparseable dates
    invalid_count = dates.isnull().sum()
    if invalid_count > 0:
        errors.append(f"Column '{date_column}' has {invalid_count} invalid dates")

    # Check range
    if min_date:
        min_dt = pd.to_datetime(min_date)
        too_early = (dates < min_dt).sum()
        if too_early > 0:
            errors.append(
                f"Column '{date_column}' has {too_early} dates before {min_date}"
            )

    if max_date:
        max_dt = pd.to_datetime(max_date)
        too_late = (dates > max_dt).sum()
        if too_late > 0:
            errors.append(
                f"Column '{date_column}' has {too_late} dates after {max_date}"
            )

    is_valid = len(errors) == 0
    return is_valid, errors


def validate_unique(
    df: pd.DataFrame,
    columns: list[str],
) -> tuple[bool, list[str]]:
    """
    Validate that specified columns have unique values (no duplicates).

    Args:
        df: DataFrame to validate
        columns: List of column names that should be unique

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors: list[str] = []

    for col in columns:
        if col not in df.columns:
            errors.append(f"Column '{col}' not found in DataFrame")
            continue

        duplicate_count = df[col].duplicated().sum()
        if duplicate_count > 0:
            errors.append(f"Column '{col}' has {duplicate_count} duplicate values")

    is_valid = len(errors) == 0
    return is_valid, errors


def validate_referential_integrity(
    df: pd.DataFrame,
    column: str,
    reference_values: set,
) -> tuple[bool, list[str]]:
    """
    Validate that values in a column exist in a reference set.

    Args:
        df: DataFrame to validate
        column: Column name to check
        reference_values: Set of valid values

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors: list[str] = []

    if column not in df.columns:
        errors.append(f"Column '{column}' not found in DataFrame")
        return False, errors

    actual_values = set(df[column].dropna())
    invalid_values = actual_values - reference_values

    if invalid_values:
        sample = list(invalid_values)[:5]
        errors.append(
            f"Column '{column}' has {len(invalid_values)} values "
            f"not in reference (sample: {sample})"
        )

    is_valid = len(errors) == 0
    return is_valid, errors
