"""
DAG: dag_transform_ecommerce

Transformation pipeline for e-commerce data.
- Executes SQL transformations for staging layer
- Executes SQL transformations for mart layer
- Runs data quality checks on marts
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from pathlib import Path

from airflow import DAG
from airflow.decorators import task
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.postgres.operators.postgres import PostgresOperator

# Configure logging
logger = logging.getLogger(__name__)

# DAG default arguments
default_args = {
    "owner": "data-engineering",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 3,
    "retry_delay": timedelta(minutes=2),
    "retry_exponential_backoff": True,
    "max_retry_delay": timedelta(minutes=30),
    "execution_timeout": timedelta(minutes=60),
}

# Paths
SQL_DIR = Path("/opt/airflow/sql")

# Postgres connection
POSTGRES_CONN_ID = "postgres_dwh"


def read_sql_file(file_path: Path, ds: str = None) -> str:
    """
    Read SQL file and replace template variables.

    Args:
        file_path: Path to SQL file
        ds: Execution date for template substitution

    Returns:
        SQL string with substituted variables
    """
    with open(file_path) as f:
        sql = f.read()

    # Replace template variables
    if ds:
        sql = sql.replace("{{ ds }}", ds)
        sql = sql.replace("{{ds}}", ds)

    return sql


@task(retries=3)
def run_sql_staging(ds: str, **kwargs) -> dict:
    """
    Execute staging SQL transformations.

    Runs all SQL files in /sql/staging/ directory.
    Uses TRUNCATE + INSERT pattern for idempotence.

    Args:
        ds: Execution date

    Returns:
        Execution statistics
    """
    hook = PostgresHook(postgres_conn_id=POSTGRES_CONN_ID)

    staging_dir = SQL_DIR / "staging"
    sql_files = sorted(staging_dir.glob("*.sql"))

    results = []

    for sql_file in sql_files:
        logger.info(f"Executing staging SQL: {sql_file.name}")

        try:
            sql = read_sql_file(sql_file, ds=ds)
            hook.run(sql)
            results.append({
                "file": sql_file.name,
                "status": "success",
            })
            logger.info(f"Successfully executed {sql_file.name}")
        except Exception as e:
            logger.error(f"Error executing {sql_file.name}: {e}")
            results.append({
                "file": sql_file.name,
                "status": "failed",
                "error": str(e),
            })
            raise

    return {"staging_results": results, "date": ds}


@task(retries=3)
def run_sql_mart(staging_results: dict, ds: str, **kwargs) -> dict:
    """
    Execute mart SQL transformations.

    Runs all SQL files in /sql/mart/ directory.
    Depends on staging transformations completing first.

    Args:
        staging_results: Results from staging step
        ds: Execution date

    Returns:
        Execution statistics
    """
    hook = PostgresHook(postgres_conn_id=POSTGRES_CONN_ID)

    mart_dir = SQL_DIR / "mart"
    sql_files = sorted(mart_dir.glob("*.sql"))

    results = []

    for sql_file in sql_files:
        logger.info(f"Executing mart SQL: {sql_file.name}")

        try:
            sql = read_sql_file(sql_file, ds=ds)
            hook.run(sql)
            results.append({
                "file": sql_file.name,
                "status": "success",
            })
            logger.info(f"Successfully executed {sql_file.name}")
        except Exception as e:
            logger.error(f"Error executing {sql_file.name}: {e}")
            results.append({
                "file": sql_file.name,
                "status": "failed",
                "error": str(e),
            })
            raise

    return {"mart_results": results, "date": ds}


@task(retries=2)
def dq_mart_checks(mart_results: dict, ds: str, **kwargs) -> dict:
    """
    Run data quality checks on mart tables.

    Checks:
    - Revenue values are non-negative
    - No duplicate rows in aggregated tables
    - Data freshness (latest date within expected range)
    """
    import sys
    sys.path.insert(0, "/opt/airflow/src")
    from utils import run_dq_check

    hook = PostgresHook(postgres_conn_id=POSTGRES_CONN_ID)

    checks = []

    # Check 1: Revenue is non-negative
    result = run_dq_check(
        hook=hook,
        check_name="revenue_non_negative",
        sql="""
            SELECT COUNT(*) = 0 as passed
            FROM mart.revenue_daily
            WHERE total_revenue < 0
        """,
    )
    checks.append(result)

    # Check 2: No duplicates in revenue_daily (unique by date)
    result = run_dq_check(
        hook=hook,
        check_name="revenue_daily_no_duplicates",
        sql="""
            SELECT COUNT(*) = COUNT(DISTINCT order_date) as passed
            FROM mart.revenue_daily
        """,
    )
    checks.append(result)

    # Check 3: Data freshness - most recent data is within 2 days
    result = run_dq_check(
        hook=hook,
        check_name="revenue_daily_freshness",
        sql=f"""
            SELECT MAX(order_date) >= '{ds}'::date - INTERVAL '2 days' as passed
            FROM mart.revenue_daily
        """,
    )
    checks.append(result)

    # Check 4: Top products has data
    result = run_dq_check(
        hook=hook,
        check_name="top_products_has_data",
        sql="""
            SELECT COUNT(*) > 0 as passed
            FROM mart.top_products
        """,
    )
    checks.append(result)

    # Check 5: Customer LTV is non-negative
    result = run_dq_check(
        hook=hook,
        check_name="customer_ltv_non_negative",
        sql="""
            SELECT COUNT(*) = 0 as passed
            FROM mart.customer_ltv
            WHERE lifetime_value < 0
        """,
    )
    checks.append(result)

    # Summarize results
    passed = sum(1 for c in checks if c["passed"])
    failed = len(checks) - passed

    logger.info(f"Mart DQ Checks: {passed}/{len(checks)} passed")

    if failed > 0:
        failed_checks = [c for c in checks if not c["passed"]]
        logger.warning(f"Failed checks: {failed_checks}")
        # Don't fail the task, just warn
        # raise ValueError(f"Data quality checks failed: {failed_checks}")

    return {"checks": checks, "passed": passed, "failed": failed, "date": ds}


# DAG Definition
with DAG(
    dag_id="dag_transform_ecommerce",
    default_args=default_args,
    description="Transform e-commerce data from raw to staging and mart layers",
    schedule_interval=None,  # Triggered by dag_daily_end_to_end
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["ecommerce", "transformation", "staging", "mart"],
    doc_md=__doc__,
    max_active_runs=1,
) as dag:

    # Run staging transformations
    staging_done = run_sql_staging(ds="{{ ds }}")

    # Run mart transformations
    mart_done = run_sql_mart(staging_done, ds="{{ ds }}")

    # Data quality checks on marts
    dq_results = dq_mart_checks(mart_done, ds="{{ ds }}")
