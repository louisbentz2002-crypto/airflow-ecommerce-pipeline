"""
Utilities Module

Helper functions for Airflow DAGs and data processing.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def run_dq_check(
    hook,
    check_name: str,
    sql: str,
) -> dict[str, Any]:
    """
    Run a data quality check using a SQL query.

    The SQL query should return a single row with a 'passed' column
    that is True/False.

    Args:
        hook: Airflow PostgresHook instance
        check_name: Name of the check (for logging)
        sql: SQL query that returns a 'passed' boolean

    Returns:
        Dictionary with check results
    """
    logger.info(f"Running DQ check: {check_name}")

    try:
        result = hook.get_first(sql)

        if result is None:
            passed = False
            message = "Query returned no results"
        else:
            passed = bool(result[0])
            message = "Check passed" if passed else "Check failed"

        logger.info(f"DQ check '{check_name}': {message}")

        return {
            "check_name": check_name,
            "passed": passed,
            "message": message,
            "executed_at": datetime.utcnow().isoformat(),
        }

    except Exception as e:
        logger.error(f"DQ check '{check_name}' error: {e}")
        return {
            "check_name": check_name,
            "passed": False,
            "message": str(e),
            "executed_at": datetime.utcnow().isoformat(),
        }


def get_sql_files(directory: str | Path, pattern: str = "*.sql") -> list[Path]:
    """
    Get list of SQL files in a directory.

    Args:
        directory: Directory path
        pattern: Glob pattern for SQL files

    Returns:
        List of Path objects sorted alphabetically
    """
    directory = Path(directory)

    if not directory.exists():
        logger.warning(f"Directory not found: {directory}")
        return []

    files = sorted(directory.glob(pattern))
    logger.info(f"Found {len(files)} SQL files in {directory}")

    return files


def read_sql_file(file_path: str | Path, **kwargs) -> str:
    """
    Read SQL file and substitute template variables.

    Args:
        file_path: Path to SQL file
        **kwargs: Variables to substitute (e.g., ds='2024-01-01')

    Returns:
        SQL string with substituted variables
    """
    file_path = Path(file_path)

    with open(file_path, "r", encoding="utf-8") as f:
        sql = f.read()

    # Substitute Airflow-style templates
    for key, value in kwargs.items():
        sql = sql.replace(f"{{{{ {key} }}}}", str(value))
        sql = sql.replace(f"{{{{{key}}}}}", str(value))

    return sql


def chunk_dataframe(df, chunk_size: int = 1000):
    """
    Split a DataFrame into chunks.

    Args:
        df: pandas DataFrame
        chunk_size: Number of rows per chunk

    Yields:
        DataFrame chunks
    """
    for start in range(0, len(df), chunk_size):
        yield df.iloc[start:start + chunk_size]


def format_execution_date(ds: str, format_out: str = "%Y%m%d") -> str:
    """
    Format Airflow execution date string.

    Args:
        ds: Execution date in YYYY-MM-DD format
        format_out: Output format string

    Returns:
        Formatted date string
    """
    dt = datetime.strptime(ds, "%Y-%m-%d")
    return dt.strftime(format_out)


def get_date_partition(ds: str) -> str:
    """
    Get date partition string for table names.

    Args:
        ds: Execution date in YYYY-MM-DD format

    Returns:
        Partition string (e.g., 'p2024_01_01')
    """
    return f"p{ds.replace('-', '_')}"


def retry_with_backoff(
    func,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    exponential_base: float = 2.0,
):
    """
    Retry a function with exponential backoff.

    Args:
        func: Function to retry (callable)
        max_retries: Maximum number of retry attempts
        base_delay: Initial delay in seconds
        max_delay: Maximum delay between retries
        exponential_base: Base for exponential backoff

    Returns:
        Function result

    Raises:
        Last exception if all retries fail
    """
    import time

    last_exception = None

    for attempt in range(max_retries + 1):
        try:
            return func()
        except Exception as e:
            last_exception = e
            if attempt < max_retries:
                delay = min(
                    base_delay * (exponential_base ** attempt),
                    max_delay
                )
                logger.warning(
                    f"Attempt {attempt + 1} failed: {e}. "
                    f"Retrying in {delay:.1f}s..."
                )
                time.sleep(delay)
            else:
                logger.error(f"All {max_retries + 1} attempts failed")

    raise last_exception


def sanitize_table_name(name: str) -> str:
    """
    Sanitize a string for use as a PostgreSQL table name.

    Args:
        name: Raw table name

    Returns:
        Sanitized table name
    """
    import re

    # Remove non-alphanumeric characters except underscore
    sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", name)

    # Ensure it starts with a letter or underscore
    if sanitized and sanitized[0].isdigit():
        sanitized = f"t_{sanitized}"

    # Lowercase
    sanitized = sanitized.lower()

    # Limit length
    return sanitized[:63]


def log_dataframe_info(df, name: str = "DataFrame") -> None:
    """
    Log DataFrame information for debugging.

    Args:
        df: pandas DataFrame
        name: Name to use in log messages
    """
    logger.info(f"{name}: {len(df)} rows, {len(df.columns)} columns")
    logger.debug(f"{name} columns: {list(df.columns)}")
    logger.debug(f"{name} dtypes:\n{df.dtypes}")

    # Log null counts
    null_counts = df.isnull().sum()
    if null_counts.any():
        logger.debug(f"{name} null counts:\n{null_counts[null_counts > 0]}")
