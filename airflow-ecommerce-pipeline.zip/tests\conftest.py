"""
Pytest configuration and fixtures.
"""

import sys
from pathlib import Path

import pytest

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


@pytest.fixture(scope="session")
def project_root() -> Path:
    """Return the project root directory."""
    return Path(__file__).parent.parent


@pytest.fixture(scope="session")
def sql_dir(project_root: Path) -> Path:
    """Return the SQL directory."""
    return project_root / "sql"


@pytest.fixture(scope="session")
def data_dir(project_root: Path) -> Path:
    """Return the data directory."""
    return project_root / "data"


@pytest.fixture
def sample_orders_df():
    """Create a sample orders DataFrame for testing."""
    import pandas as pd

    return pd.DataFrame({
        "order_id": [1, 2, 3, 4, 5],
        "customer_id": [101, 102, 103, 101, 104],
        "product_id": [201, 202, 203, 201, 204],
        "quantity": [1, 2, 1, 3, 1],
        "unit_price": [29.99, 49.99, 19.99, 29.99, 99.99],
        "total_amount": [29.99, 99.98, 19.99, 89.97, 99.99],
        "order_date": [
            "2024-01-01",
            "2024-01-02",
            "2024-01-02",
            "2024-01-03",
            "2024-01-03",
        ],
        "order_status": ["COMPLETED", "COMPLETED", "PENDING", "SHIPPED", "COMPLETED"],
    })


@pytest.fixture
def sample_customers_df():
    """Create a sample customers DataFrame for testing."""
    import pandas as pd

    return pd.DataFrame({
        "customer_id": [101, 102, 103, 104],
        "first_name": ["John", "Jane", "Bob", "Alice"],
        "last_name": ["Doe", "Smith", "Wilson", "Johnson"],
        "email": [
            "john@example.com",
            "jane@example.com",
            "bob@example.com",
            "alice@example.com",
        ],
        "city": ["Paris", "London", "Berlin", "Madrid"],
        "country": ["FR", "UK", "DE", "ES"],
    })


@pytest.fixture
def sample_products_df():
    """Create a sample products DataFrame for testing."""
    import pandas as pd

    return pd.DataFrame({
        "product_id": [201, 202, 203, 204],
        "product_name": ["Widget A", "Gadget B", "Tool C", "Device D"],
        "category": ["Electronics", "Electronics", "Home", "Electronics"],
        "price": [29.99, 49.99, 19.99, 99.99],
        "cost": [15.00, 25.00, 10.00, 50.00],
        "stock_quantity": [100, 50, 200, 25],
    })
