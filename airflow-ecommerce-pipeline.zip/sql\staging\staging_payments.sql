-- ============================================
-- STAGING: Payments
-- ============================================
-- Clean, type, and deduplicate payments from raw layer
-- Idempotent: TRUNCATE + INSERT pattern

-- Truncate staging table for idempotence
TRUNCATE TABLE staging.stg_payments;

-- Insert cleaned and typed data
INSERT INTO staging.stg_payments (
    payment_id,
    order_id,
    payment_method,
    payment_amount,
    payment_date,
    payment_status,
    _loaded_at,
    _execution_date
)
SELECT DISTINCT ON (CAST(payment_id AS INTEGER))
    -- Type conversions
    CAST(payment_id AS INTEGER) AS payment_id,
    CAST(order_id AS INTEGER) AS order_id,
    -- Normalize payment method
    UPPER(TRIM(COALESCE(payment_method, 'UNKNOWN'))) AS payment_method,
    -- Amount
    COALESCE(payment_amount, 0) AS payment_amount,
    -- Parse date
    CASE
        WHEN payment_date ~ '^\d{4}-\d{2}-\d{2}' THEN CAST(payment_date AS DATE)
        WHEN payment_date ~ '^\d{2}/\d{2}/\d{4}' THEN TO_DATE(payment_date, 'DD/MM/YYYY')
        ELSE CURRENT_DATE
    END AS payment_date,
    -- Normalize status
    UPPER(TRIM(COALESCE(payment_status, 'PENDING'))) AS payment_status,
    _loaded_at,
    _execution_date
FROM raw.raw_payments
WHERE
    -- Filter valid records
    payment_id IS NOT NULL
    AND order_id IS NOT NULL
    -- Amount must be non-negative
    AND COALESCE(payment_amount, 0) >= 0
ORDER BY
    CAST(payment_id AS INTEGER),
    _loaded_at DESC  -- Keep most recent in case of duplicates
;

-- Log row count
DO $$
BEGIN
    RAISE NOTICE 'Staging payments loaded: % rows',
        (SELECT COUNT(*) FROM staging.stg_payments);
END $$;
