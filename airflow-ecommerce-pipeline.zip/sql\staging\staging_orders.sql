-- ============================================
-- STAGING: Orders
-- ============================================
-- Clean, type, and deduplicate orders from raw layer
-- Idempotent: TRUNCATE + INSERT pattern

-- Truncate staging table for idempotence
TRUNCATE TABLE staging.stg_orders;

-- Insert cleaned and typed data
INSERT INTO staging.stg_orders (
    order_id,
    customer_id,
    product_id,
    quantity,
    unit_price,
    total_amount,
    order_date,
    order_status,
    shipping_address,
    _loaded_at,
    _execution_date
)
SELECT DISTINCT ON (CAST(order_id AS INTEGER))
    -- Type conversions
    CAST(order_id AS INTEGER) AS order_id,
    CAST(customer_id AS INTEGER) AS customer_id,
    CAST(product_id AS INTEGER) AS product_id,
    COALESCE(quantity, 1) AS quantity,
    COALESCE(unit_price, 0) AS unit_price,
    -- Recalculate total if missing
    COALESCE(
        total_amount,
        COALESCE(quantity, 1) * COALESCE(unit_price, 0)
    ) AS total_amount,
    -- Parse date with fallback
    CASE
        WHEN order_date ~ '^\d{4}-\d{2}-\d{2}' THEN CAST(order_date AS DATE)
        WHEN order_date ~ '^\d{2}/\d{2}/\d{4}' THEN TO_DATE(order_date, 'DD/MM/YYYY')
        ELSE CURRENT_DATE
    END AS order_date,
    -- Normalize status
    UPPER(TRIM(COALESCE(order_status, 'UNKNOWN'))) AS order_status,
    TRIM(shipping_address) AS shipping_address,
    _loaded_at,
    _execution_date
FROM raw.raw_orders
WHERE
    -- Filter valid records
    order_id IS NOT NULL
    AND customer_id IS NOT NULL
    AND product_id IS NOT NULL
    -- Filter valid amounts
    AND COALESCE(unit_price, 0) >= 0
    AND COALESCE(quantity, 1) > 0
ORDER BY
    CAST(order_id AS INTEGER),
    _loaded_at DESC  -- Keep most recent in case of duplicates
;

-- Log row count
DO $$
BEGIN
    RAISE NOTICE 'Staging orders loaded: % rows',
        (SELECT COUNT(*) FROM staging.stg_orders);
END $$;
