-- ============================================
-- MART: Top Products
-- ============================================
-- Top products by revenue over rolling 7-day window
-- Idempotent: DELETE + INSERT by period

-- Calculate date range
DO $$
DECLARE
    v_end_date DATE := CURRENT_DATE;
    v_start_date DATE := CURRENT_DATE - INTERVAL '7 days';
BEGIN
    -- Delete existing data for this period
    DELETE FROM mart.top_products
    WHERE period_start = v_start_date AND period_end = v_end_date;
END $$;

-- Insert top products
WITH product_metrics AS (
    SELECT
        o.product_id,
        p.product_name,
        p.category,
        SUM(o.quantity) AS total_quantity,
        SUM(o.total_amount) AS total_revenue,
        COUNT(DISTINCT o.order_id) AS order_count
    FROM staging.stg_orders o
    INNER JOIN staging.stg_products p ON o.product_id = p.product_id
    WHERE
        o.order_date >= CURRENT_DATE - INTERVAL '7 days'
        AND o.order_date <= CURRENT_DATE
        AND o.order_status IN ('COMPLETED', 'DELIVERED', 'SHIPPED', 'PAID')
    GROUP BY
        o.product_id,
        p.product_name,
        p.category
),
ranked_products AS (
    SELECT
        *,
        ROW_NUMBER() OVER (ORDER BY total_revenue DESC) AS rank
    FROM product_metrics
)
INSERT INTO mart.top_products (
    product_id,
    product_name,
    category,
    total_quantity,
    total_revenue,
    order_count,
    rank,
    period_start,
    period_end,
    _updated_at
)
SELECT
    product_id,
    product_name,
    category,
    total_quantity,
    total_revenue,
    order_count,
    rank,
    CURRENT_DATE - INTERVAL '7 days' AS period_start,
    CURRENT_DATE AS period_end,
    CURRENT_TIMESTAMP AS _updated_at
FROM ranked_products
WHERE rank <= 50  -- Top 50 products
ORDER BY rank
ON CONFLICT (product_id, period_start)
DO UPDATE SET
    product_name = EXCLUDED.product_name,
    category = EXCLUDED.category,
    total_quantity = EXCLUDED.total_quantity,
    total_revenue = EXCLUDED.total_revenue,
    order_count = EXCLUDED.order_count,
    rank = EXCLUDED.rank,
    period_end = EXCLUDED.period_end,
    _updated_at = EXCLUDED._updated_at
;

-- Log summary
DO $$
DECLARE
    v_top_product VARCHAR;
    v_top_revenue DECIMAL;
BEGIN
    SELECT product_name, total_revenue
    INTO v_top_product, v_top_revenue
    FROM mart.top_products
    WHERE period_end = CURRENT_DATE
    ORDER BY rank
    LIMIT 1;

    RAISE NOTICE 'Top Product: % with revenue %', v_top_product, v_top_revenue;
END $$;
