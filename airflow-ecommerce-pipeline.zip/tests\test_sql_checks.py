"""
Tests for SQL data quality checks.

These tests verify that the SQL check queries are syntactically correct
and can be executed against a mock/test database.
"""

import pytest

# SQL check queries used by the DAGs
SQL_CHECKS = {
    "count_check_orders": """
        SELECT COUNT(*) > 0 as passed
        FROM {schema}.{table}
        WHERE _execution_date = '{date}'
    """,
    "null_pk_orders": """
        SELECT COUNT(*) = 0 as passed
        FROM {schema}.{table}
        WHERE order_id IS NULL
        AND _execution_date = '{date}'
    """,
    "valid_order_dates": """
        SELECT COUNT(*) = 0 as passed
        FROM {schema}.{table}
        WHERE order_date > CURRENT_DATE + INTERVAL '1 day'
        OR order_date < '2020-01-01'
    """,
    "revenue_non_negative": """
        SELECT COUNT(*) = 0 as passed
        FROM {schema}.{table}
        WHERE total_revenue < 0
    """,
    "revenue_daily_no_duplicates": """
        SELECT COUNT(*) = COUNT(DISTINCT order_date) as passed
        FROM {schema}.{table}
    """,
    "customer_ltv_non_negative": """
        SELECT COUNT(*) = 0 as passed
        FROM {schema}.{table}
        WHERE lifetime_value < 0
    """,
}


class TestSQLCheckSyntax:
    """Tests to verify SQL check queries are syntactically valid."""

    def test_count_check_syntax(self):
        """Test count check SQL is valid format."""
        sql = SQL_CHECKS["count_check_orders"]
        sql_formatted = sql.format(
            schema="raw",
            table="raw_orders",
            date="2024-01-01"
        )

        # Check key SQL elements are present
        assert "SELECT" in sql_formatted.upper()
        assert "FROM" in sql_formatted.upper()
        assert "COUNT(*)" in sql_formatted.upper()
        assert "passed" in sql_formatted.lower()

    def test_null_pk_check_syntax(self):
        """Test null PK check SQL is valid format."""
        sql = SQL_CHECKS["null_pk_orders"]
        sql_formatted = sql.format(
            schema="raw",
            table="raw_orders",
            date="2024-01-01"
        )

        assert "IS NULL" in sql_formatted.upper()
        assert "COUNT(*) = 0" in sql_formatted.upper()

    def test_date_range_check_syntax(self):
        """Test date range check SQL is valid format."""
        sql = SQL_CHECKS["valid_order_dates"]
        sql_formatted = sql.format(
            schema="raw",
            table="raw_orders"
        )

        assert "CURRENT_DATE" in sql_formatted.upper()
        assert "INTERVAL" in sql_formatted.upper()

    def test_revenue_non_negative_syntax(self):
        """Test revenue non-negative check SQL is valid format."""
        sql = SQL_CHECKS["revenue_non_negative"]
        sql_formatted = sql.format(
            schema="mart",
            table="revenue_daily"
        )

        assert "< 0" in sql_formatted
        assert "total_revenue" in sql_formatted.lower()

    def test_no_duplicates_check_syntax(self):
        """Test no duplicates check SQL is valid format."""
        sql = SQL_CHECKS["revenue_daily_no_duplicates"]
        sql_formatted = sql.format(
            schema="mart",
            table="revenue_daily"
        )

        assert "COUNT(*)" in sql_formatted.upper()
        assert "DISTINCT" in sql_formatted.upper()


class TestSQLCheckQueries:
    """Test SQL check query structures."""

    @pytest.mark.parametrize("check_name,sql_template", list(SQL_CHECKS.items()))
    def test_all_checks_have_passed_column(self, check_name, sql_template):
        """Test all check queries return a 'passed' column."""
        assert "passed" in sql_template.lower(), \
            f"Check '{check_name}' missing 'passed' column"

    @pytest.mark.parametrize("check_name,sql_template", list(SQL_CHECKS.items()))
    def test_all_checks_are_boolean_expressions(self, check_name, sql_template):
        """Test all check queries return boolean expressions."""
        # Should contain comparison operators
        has_comparison = any(op in sql_template for op in [
            "> 0", "< 0", "= 0", ">= 0", "<= 0",
            "> 1", "= 1",
            "IS NULL", "IS NOT NULL",
        ])
        assert has_comparison, \
            f"Check '{check_name}' doesn't appear to be a boolean check"


class TestDQCheckFunctions:
    """Tests for the run_dq_check utility function."""

    def test_run_dq_check_result_structure(self):
        """Test the expected result structure from run_dq_check."""
        # Expected structure
        expected_keys = ["check_name", "passed", "message", "executed_at"]

        # Mock result
        result = {
            "check_name": "test_check",
            "passed": True,
            "message": "Check passed",
            "executed_at": "2024-01-01T12:00:00",
        }

        for key in expected_keys:
            assert key in result, f"Missing key: {key}"

    def test_check_passed_result(self):
        """Test result structure for a passing check."""
        result = {
            "check_name": "count_check",
            "passed": True,
            "message": "Check passed",
            "executed_at": "2024-01-01T12:00:00",
        }

        assert result["passed"] is True
        assert "passed" in result["message"].lower()

    def test_check_failed_result(self):
        """Test result structure for a failing check."""
        result = {
            "check_name": "null_check",
            "passed": False,
            "message": "Check failed: 5 null values found",
            "executed_at": "2024-01-01T12:00:00",
        }

        assert result["passed"] is False
        assert result["check_name"] == "null_check"


# Integration test marker for tests that need a real database
@pytest.mark.integration
class TestSQLChecksIntegration:
    """Integration tests that require a PostgreSQL database."""

    @pytest.mark.skip(reason="Requires PostgreSQL database")
    def test_execute_count_check(self):
        """Test executing count check against real database."""
        pass

    @pytest.mark.skip(reason="Requires PostgreSQL database")
    def test_execute_all_checks(self):
        """Test executing all checks against real database."""
        pass
