"""
Tests for data_generator module.
"""

from datetime import date
from pathlib import Path

import pandas as pd
import pytest

from src.data_generator import EcommerceDataGenerator


class TestEcommerceDataGenerator:
    """Tests for EcommerceDataGenerator class."""

    @pytest.fixture
    def generator(self):
        """Create a generator with fixed seed for reproducibility."""
        return EcommerceDataGenerator(seed=42)

    def test_initialization(self, generator):
        """Test generator initializes correctly."""
        assert generator.seed == 42
        assert generator.faker is not None

    def test_reproducibility(self):
        """Test that same seed produces same results."""
        gen1 = EcommerceDataGenerator(seed=123)
        gen2 = EcommerceDataGenerator(seed=123)

        customers1 = gen1.generate_customers(n=10)
        customers2 = gen2.generate_customers(n=10)

        pd.testing.assert_frame_equal(customers1, customers2)


class TestGenerateCustomers:
    """Tests for generate_customers method."""

    @pytest.fixture
    def generator(self):
        return EcommerceDataGenerator(seed=42)

    def test_generates_correct_count(self, generator):
        """Test correct number of customers generated."""
        df = generator.generate_customers(n=100)
        assert len(df) == 100

    def test_has_required_columns(self, generator):
        """Test generated DataFrame has required columns."""
        df = generator.generate_customers(n=10)

        required_cols = [
            "customer_id",
            "first_name",
            "last_name",
            "email",
            "phone",
            "address",
            "city",
            "country",
            "created_at",
        ]
        for col in required_cols:
            assert col in df.columns, f"Missing column: {col}"

    def test_customer_ids_are_sequential(self, generator):
        """Test customer IDs start at 1 and are sequential."""
        df = generator.generate_customers(n=50)
        expected_ids = list(range(1, 51))
        assert df["customer_id"].tolist() == expected_ids

    def test_emails_are_valid_format(self, generator):
        """Test generated emails have valid format."""
        df = generator.generate_customers(n=10)
        for email in df["email"]:
            assert "@" in email, f"Invalid email: {email}"
            assert "." in email, f"Invalid email: {email}"


class TestGenerateProducts:
    """Tests for generate_products method."""

    @pytest.fixture
    def generator(self):
        return EcommerceDataGenerator(seed=42)

    def test_generates_correct_count(self, generator):
        """Test correct number of products generated."""
        df = generator.generate_products(n=50)
        assert len(df) == 50

    def test_has_required_columns(self, generator):
        """Test generated DataFrame has required columns."""
        df = generator.generate_products(n=10)

        required_cols = [
            "product_id",
            "product_name",
            "category",
            "subcategory",
            "price",
            "cost",
            "stock_quantity",
            "supplier",
        ]
        for col in required_cols:
            assert col in df.columns, f"Missing column: {col}"

    def test_prices_are_positive(self, generator):
        """Test all prices are positive."""
        df = generator.generate_products(n=100)
        assert (df["price"] > 0).all()

    def test_costs_are_less_than_prices(self, generator):
        """Test costs are less than or equal to prices."""
        df = generator.generate_products(n=100)
        assert (df["cost"] <= df["price"]).all()

    def test_categories_are_valid(self, generator):
        """Test categories are from expected list."""
        df = generator.generate_products(n=100)
        valid_categories = set(EcommerceDataGenerator.CATEGORIES.keys())
        assert set(df["category"].unique()).issubset(valid_categories)


class TestGenerateOrders:
    """Tests for generate_orders method."""

    @pytest.fixture
    def generator(self):
        return EcommerceDataGenerator(seed=42)

    def test_generates_correct_count(self, generator):
        """Test correct number of orders generated."""
        df = generator.generate_orders(n=100)
        assert len(df) == 100

    def test_has_required_columns(self, generator):
        """Test generated DataFrame has required columns."""
        df = generator.generate_orders(n=10)

        required_cols = [
            "order_id",
            "customer_id",
            "product_id",
            "quantity",
            "unit_price",
            "total_amount",
            "order_date",
            "order_status",
            "shipping_address",
        ]
        for col in required_cols:
            assert col in df.columns, f"Missing column: {col}"

    def test_total_amount_calculation(self, generator):
        """Test total_amount equals quantity * unit_price."""
        df = generator.generate_orders(n=50)
        expected_totals = df["quantity"] * df["unit_price"]
        pd.testing.assert_series_equal(
            df["total_amount"],
            expected_totals,
            check_names=False,
        )

    def test_quantities_are_positive(self, generator):
        """Test all quantities are positive."""
        df = generator.generate_orders(n=100)
        assert (df["quantity"] > 0).all()

    def test_uses_provided_customer_ids(self, generator):
        """Test orders use provided customer IDs."""
        customer_ids = [10, 20, 30]
        df = generator.generate_orders(n=10, customer_ids=customer_ids)
        assert set(df["customer_id"].unique()).issubset(set(customer_ids))

    def test_uses_provided_product_ids(self, generator):
        """Test orders use provided product IDs."""
        product_ids = [100, 200, 300]
        df = generator.generate_orders(n=10, product_ids=product_ids)
        assert set(df["product_id"].unique()).issubset(set(product_ids))

    def test_uses_specific_date(self, generator):
        """Test orders use specific date when provided."""
        specific_date = date(2024, 6, 15)
        df = generator.generate_orders(n=10, date=specific_date)
        assert (df["order_date"] == "2024-06-15").all()

    def test_order_statuses_are_valid(self, generator):
        """Test order statuses are from expected list."""
        df = generator.generate_orders(n=100)
        valid_statuses = {s[0] for s in EcommerceDataGenerator.ORDER_STATUSES}
        assert set(df["order_status"].unique()).issubset(valid_statuses)


class TestGeneratePayments:
    """Tests for generate_payments method."""

    @pytest.fixture
    def generator(self):
        return EcommerceDataGenerator(seed=42)

    def test_generates_one_payment_per_order(self, generator):
        """Test one payment generated per order."""
        order_ids = [1, 2, 3, 4, 5]
        df = generator.generate_payments(order_ids=order_ids)
        assert len(df) == len(order_ids)

    def test_has_required_columns(self, generator):
        """Test generated DataFrame has required columns."""
        df = generator.generate_payments(order_ids=[1, 2, 3])

        required_cols = [
            "payment_id",
            "order_id",
            "payment_method",
            "payment_amount",
            "payment_date",
            "payment_status",
        ]
        for col in required_cols:
            assert col in df.columns, f"Missing column: {col}"

    def test_payment_methods_are_valid(self, generator):
        """Test payment methods are from expected list."""
        df = generator.generate_payments(order_ids=list(range(1, 101)))
        valid_methods = {m[0] for m in EcommerceDataGenerator.PAYMENT_METHODS}
        assert set(df["payment_method"].unique()).issubset(valid_methods)

    def test_payment_amounts_are_positive(self, generator):
        """Test all payment amounts are positive."""
        df = generator.generate_payments(order_ids=list(range(1, 101)))
        assert (df["payment_amount"] > 0).all()


class TestGenerateAll:
    """Tests for generate_all method."""

    @pytest.fixture
    def generator(self):
        return EcommerceDataGenerator(seed=42)

    def test_creates_all_files(self, generator, tmp_path: Path):
        """Test all CSV files are created."""
        files = generator.generate_all(
            output_dir=tmp_path,
            n_customers=10,
            n_products=5,
            n_orders=20,
        )

        assert "customers" in files
        assert "products" in files
        assert "orders" in files
        assert "payments" in files

        for name, path in files.items():
            assert Path(path).exists(), f"File not created: {path}"

    def test_creates_output_directory(self, generator, tmp_path: Path):
        """Test output directory is created if it doesn't exist."""
        output_dir = tmp_path / "nested" / "dir"
        generator.generate_all(
            output_dir=output_dir,
            n_customers=5,
            n_products=5,
            n_orders=5,
        )

        assert output_dir.exists()

    def test_files_are_valid_csv(self, generator, tmp_path: Path):
        """Test generated files are valid CSV."""
        files = generator.generate_all(
            output_dir=tmp_path,
            n_customers=10,
            n_products=10,
            n_orders=10,
        )

        for name, path in files.items():
            df = pd.read_csv(path)
            assert len(df) > 0, f"Empty file: {path}"
