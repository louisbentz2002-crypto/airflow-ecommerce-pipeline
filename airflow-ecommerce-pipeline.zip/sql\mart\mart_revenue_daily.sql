-- ============================================
-- MART: Revenue Daily
-- ============================================
-- Daily aggregated revenue metrics
-- Idempotent: DELETE + INSERT by date

-- Delete existing data for the date range being processed
DELETE FROM mart.revenue_daily
WHERE order_date IN (SELECT DISTINCT order_date FROM staging.stg_orders);

-- Insert aggregated revenue by day
INSERT INTO mart.revenue_daily (
    order_date,
    total_orders,
    total_quantity,
    total_revenue,
    average_order_value,
    _updated_at
)
SELECT
    o.order_date,
    COUNT(DISTINCT o.order_id) AS total_orders,
    SUM(o.quantity) AS total_quantity,
    SUM(o.total_amount) AS total_revenue,
    ROUND(
        SUM(o.total_amount)::DECIMAL / NULLIF(COUNT(DISTINCT o.order_id), 0),
        2
    ) AS average_order_value,
    CURRENT_TIMESTAMP AS _updated_at
FROM staging.stg_orders o
WHERE
    -- Only completed/paid orders
    o.order_status IN ('COMPLETED', 'DELIVERED', 'SHIPPED', 'PAID')
GROUP BY o.order_date
ORDER BY o.order_date
ON CONFLICT (order_date)
DO UPDATE SET
    total_orders = EXCLUDED.total_orders,
    total_quantity = EXCLUDED.total_quantity,
    total_revenue = EXCLUDED.total_revenue,
    average_order_value = EXCLUDED.average_order_value,
    _updated_at = EXCLUDED._updated_at
;

-- Log summary
DO $$
DECLARE
    v_total_revenue DECIMAL;
    v_total_orders INTEGER;
    v_latest_date DATE;
BEGIN
    SELECT
        SUM(total_revenue),
        SUM(total_orders),
        MAX(order_date)
    INTO v_total_revenue, v_total_orders, v_latest_date
    FROM mart.revenue_daily;

    RAISE NOTICE 'Revenue Daily Summary: % total revenue, % orders, latest date: %',
        v_total_revenue, v_total_orders, v_latest_date;
END $$;
