"""
Tests for validators module.
"""

import tempfile
from pathlib import Path

import pandas as pd
import pytest

from src.validators import (
    EXPECTED_SCHEMAS,
    validate_csv_schema,
    validate_date_range,
    validate_not_null,
    validate_positive_values,
    validate_referential_integrity,
    validate_unique,
)


class TestValidateCsvSchema:
    """Tests for validate_csv_schema function."""

    def test_valid_orders_schema(self, tmp_path: Path):
        """Test validation passes for valid orders CSV."""
        # Create valid orders CSV
        df = pd.DataFrame({
            "order_id": [1, 2, 3],
            "customer_id": [100, 101, 102],
            "product_id": [200, 201, 202],
            "quantity": [1, 2, 3],
            "unit_price": [10.0, 20.0, 30.0],
            "total_amount": [10.0, 40.0, 90.0],
            "order_date": ["2024-01-01", "2024-01-02", "2024-01-03"],
            "order_status": ["COMPLETED", "PENDING", "SHIPPED"],
        })

        file_path = tmp_path / "orders.csv"
        df.to_csv(file_path, index=False)

        is_valid, errors = validate_csv_schema(file_path, EXPECTED_SCHEMAS["orders"])

        assert is_valid is True
        assert len(errors) == 0

    def test_missing_required_columns(self, tmp_path: Path):
        """Test validation fails for missing required columns."""
        # Create CSV missing required columns
        df = pd.DataFrame({
            "order_id": [1, 2, 3],
            "customer_id": [100, 101, 102],
            # Missing: product_id, quantity, unit_price, etc.
        })

        file_path = tmp_path / "orders_incomplete.csv"
        df.to_csv(file_path, index=False)

        is_valid, errors = validate_csv_schema(file_path, EXPECTED_SCHEMAS["orders"])

        assert is_valid is False
        assert len(errors) > 0
        assert any("Missing required columns" in e for e in errors)

    def test_empty_csv(self, tmp_path: Path):
        """Test validation fails for empty CSV."""
        # Create empty CSV with headers
        df = pd.DataFrame(columns=EXPECTED_SCHEMAS["orders"]["required_columns"])

        file_path = tmp_path / "orders_empty.csv"
        df.to_csv(file_path, index=False)

        is_valid, errors = validate_csv_schema(file_path, EXPECTED_SCHEMAS["orders"])

        assert is_valid is False
        assert any("empty" in e.lower() for e in errors)

    def test_file_not_found(self, tmp_path: Path):
        """Test validation handles missing file."""
        file_path = tmp_path / "nonexistent.csv"

        is_valid, errors = validate_csv_schema(file_path, EXPECTED_SCHEMAS["orders"])

        assert is_valid is False
        assert any("not found" in e.lower() for e in errors)

    def test_valid_customers_schema(self, tmp_path: Path):
        """Test validation passes for valid customers CSV."""
        df = pd.DataFrame({
            "customer_id": [1, 2, 3],
            "first_name": ["John", "Jane", "Bob"],
            "last_name": ["Doe", "Smith", "Wilson"],
            "email": ["john@example.com", "jane@example.com", "bob@example.com"],
        })

        file_path = tmp_path / "customers.csv"
        df.to_csv(file_path, index=False)

        is_valid, errors = validate_csv_schema(file_path, EXPECTED_SCHEMAS["customers"])

        assert is_valid is True
        assert len(errors) == 0


class TestValidateNotNull:
    """Tests for validate_not_null function."""

    def test_no_nulls(self):
        """Test validation passes when no nulls present."""
        df = pd.DataFrame({
            "id": [1, 2, 3],
            "name": ["A", "B", "C"],
        })

        is_valid, errors = validate_not_null(df, ["id", "name"])

        assert is_valid is True
        assert len(errors) == 0

    def test_with_nulls(self):
        """Test validation fails when nulls are present."""
        df = pd.DataFrame({
            "id": [1, None, 3],
            "name": ["A", "B", None],
        })

        is_valid, errors = validate_not_null(df, ["id", "name"])

        assert is_valid is False
        assert len(errors) == 2

    def test_column_not_found(self):
        """Test validation handles missing column."""
        df = pd.DataFrame({"id": [1, 2, 3]})

        is_valid, errors = validate_not_null(df, ["nonexistent"])

        assert is_valid is False
        assert any("not found" in e.lower() for e in errors)


class TestValidatePositiveValues:
    """Tests for validate_positive_values function."""

    def test_all_positive(self):
        """Test validation passes for all positive values."""
        df = pd.DataFrame({
            "price": [10.0, 20.0, 30.0],
            "quantity": [1, 2, 3],
        })

        is_valid, errors = validate_positive_values(df, ["price", "quantity"])

        assert is_valid is True
        assert len(errors) == 0

    def test_with_zeros(self):
        """Test validation passes with zero values (non-negative)."""
        df = pd.DataFrame({
            "price": [0.0, 10.0, 20.0],
        })

        is_valid, errors = validate_positive_values(df, ["price"])

        assert is_valid is True

    def test_with_negatives(self):
        """Test validation fails for negative values."""
        df = pd.DataFrame({
            "price": [10.0, -5.0, 20.0],
        })

        is_valid, errors = validate_positive_values(df, ["price"])

        assert is_valid is False
        assert any("negative" in e.lower() for e in errors)


class TestValidateDateRange:
    """Tests for validate_date_range function."""

    def test_valid_dates_in_range(self):
        """Test validation passes for dates within range."""
        df = pd.DataFrame({
            "date": ["2024-01-15", "2024-02-01", "2024-03-10"],
        })

        is_valid, errors = validate_date_range(
            df,
            "date",
            min_date="2024-01-01",
            max_date="2024-12-31",
        )

        assert is_valid is True
        assert len(errors) == 0

    def test_dates_before_min(self):
        """Test validation fails for dates before minimum."""
        df = pd.DataFrame({
            "date": ["2023-01-01", "2024-01-01"],
        })

        is_valid, errors = validate_date_range(
            df,
            "date",
            min_date="2024-01-01",
        )

        assert is_valid is False
        assert any("before" in e.lower() for e in errors)

    def test_dates_after_max(self):
        """Test validation fails for dates after maximum."""
        df = pd.DataFrame({
            "date": ["2024-01-01", "2025-06-01"],
        })

        is_valid, errors = validate_date_range(
            df,
            "date",
            max_date="2025-01-01",
        )

        assert is_valid is False
        assert any("after" in e.lower() for e in errors)

    def test_invalid_date_format(self):
        """Test validation handles invalid date formats."""
        df = pd.DataFrame({
            "date": ["2024-01-01", "not-a-date", "2024-03-01"],
        })

        is_valid, errors = validate_date_range(df, "date")

        assert is_valid is False
        assert any("invalid" in e.lower() for e in errors)


class TestValidateUnique:
    """Tests for validate_unique function."""

    def test_all_unique(self):
        """Test validation passes for unique values."""
        df = pd.DataFrame({
            "id": [1, 2, 3, 4, 5],
        })

        is_valid, errors = validate_unique(df, ["id"])

        assert is_valid is True
        assert len(errors) == 0

    def test_with_duplicates(self):
        """Test validation fails for duplicate values."""
        df = pd.DataFrame({
            "id": [1, 2, 2, 3, 3],
        })

        is_valid, errors = validate_unique(df, ["id"])

        assert is_valid is False
        assert any("duplicate" in e.lower() for e in errors)


class TestValidateReferentialIntegrity:
    """Tests for validate_referential_integrity function."""

    def test_valid_references(self):
        """Test validation passes for valid references."""
        df = pd.DataFrame({
            "customer_id": [1, 2, 3],
        })
        valid_customers = {1, 2, 3, 4, 5}

        is_valid, errors = validate_referential_integrity(
            df, "customer_id", valid_customers
        )

        assert is_valid is True
        assert len(errors) == 0

    def test_invalid_references(self):
        """Test validation fails for invalid references."""
        df = pd.DataFrame({
            "customer_id": [1, 2, 999],
        })
        valid_customers = {1, 2, 3}

        is_valid, errors = validate_referential_integrity(
            df, "customer_id", valid_customers
        )

        assert is_valid is False
        assert any("not in reference" in e.lower() for e in errors)
