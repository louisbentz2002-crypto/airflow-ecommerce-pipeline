"""
Data Generator Module

Generates realistic e-commerce data using Faker.
Produces CSV files for: orders, customers, products, payments.
"""

from __future__ import annotations

import logging
import random
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional

import pandas as pd
from faker import Faker

logger = logging.getLogger(__name__)


class EcommerceDataGenerator:
    """
    Generate realistic e-commerce synthetic data.

    Attributes:
        faker: Faker instance for generating fake data
        seed: Random seed for reproducibility
    """

    # Product categories with subcategories
    CATEGORIES = {
        "Electronics": ["Smartphones", "Laptops", "Tablets", "Accessories", "Audio"],
        "Clothing": ["Men", "Women", "Kids", "Sportswear", "Accessories"],
        "Home": ["Furniture", "Kitchen", "Decor", "Garden", "Lighting"],
        "Sports": ["Fitness", "Outdoor", "Team Sports", "Water Sports", "Winter"],
        "Books": ["Fiction", "Non-Fiction", "Education", "Comics", "Magazines"],
        "Beauty": ["Skincare", "Makeup", "Haircare", "Fragrance", "Tools"],
    }

    # Payment methods with weights
    PAYMENT_METHODS = [
        ("CREDIT_CARD", 0.45),
        ("DEBIT_CARD", 0.25),
        ("PAYPAL", 0.15),
        ("BANK_TRANSFER", 0.10),
        ("CRYPTO", 0.05),
    ]

    # Order statuses with weights
    ORDER_STATUSES = [
        ("COMPLETED", 0.70),
        ("SHIPPED", 0.10),
        ("DELIVERED", 0.10),
        ("PENDING", 0.05),
        ("CANCELLED", 0.05),
    ]

    # Payment statuses with weights
    PAYMENT_STATUSES = [
        ("COMPLETED", 0.85),
        ("PENDING", 0.10),
        ("FAILED", 0.03),
        ("REFUNDED", 0.02),
    ]

    def __init__(self, seed: int = 42, locale: str = "en_US"):
        """
        Initialize the data generator.

        Args:
            seed: Random seed for reproducibility
            locale: Faker locale for localized data
        """
        self.seed = seed
        self.faker = Faker(locale)
        Faker.seed(seed)
        random.seed(seed)

    def generate_customers(self, n: int = 1000) -> pd.DataFrame:
        """
        Generate customer data.

        Args:
            n: Number of customers to generate

        Returns:
            DataFrame with customer data
        """
        logger.info(f"Generating {n} customers")

        customers = []
        for i in range(1, n + 1):
            customers.append({
                "customer_id": i,
                "first_name": self.faker.first_name(),
                "last_name": self.faker.last_name(),
                "email": self.faker.email(),
                "phone": self.faker.phone_number(),
                "address": self.faker.street_address(),
                "city": self.faker.city(),
                "country": self.faker.country_code(),
                "created_at": self.faker.date_between(
                    start_date="-2y",
                    end_date="today"
                ).isoformat(),
            })

        return pd.DataFrame(customers)

    def generate_products(self, n: int = 500) -> pd.DataFrame:
        """
        Generate product catalog.

        Args:
            n: Number of products to generate

        Returns:
            DataFrame with product data
        """
        logger.info(f"Generating {n} products")

        products = []
        for i in range(1, n + 1):
            category = random.choice(list(self.CATEGORIES.keys()))
            subcategory = random.choice(self.CATEGORIES[category])

            # Generate realistic price based on category
            base_price = random.uniform(10, 500)
            if category == "Electronics":
                base_price *= 2
            elif category == "Books":
                base_price *= 0.1

            price = round(base_price, 2)
            cost = round(price * random.uniform(0.4, 0.7), 2)

            products.append({
                "product_id": i,
                "product_name": f"{self.faker.word().title()} {subcategory} {self.faker.word().title()}",
                "category": category,
                "subcategory": subcategory,
                "price": price,
                "cost": cost,
                "stock_quantity": random.randint(0, 1000),
                "supplier": self.faker.company(),
            })

        return pd.DataFrame(products)

    def generate_orders(
        self,
        n: int = 1000,
        customer_ids: Optional[list[int]] = None,
        product_ids: Optional[list[int]] = None,
        date: Optional[date] = None,
    ) -> pd.DataFrame:
        """
        Generate order data.

        Args:
            n: Number of orders to generate
            customer_ids: List of valid customer IDs
            product_ids: List of valid product IDs
            date: Specific date for orders (default: random in last 30 days)

        Returns:
            DataFrame with order data
        """
        logger.info(f"Generating {n} orders")

        if customer_ids is None:
            customer_ids = list(range(1, 1001))
        if product_ids is None:
            product_ids = list(range(1, 501))

        orders = []
        for i in range(1, n + 1):
            # Generate order date
            if date:
                order_date = date
            else:
                order_date = self.faker.date_between(
                    start_date="-30d",
                    end_date="today"
                )

            quantity = random.randint(1, 10)
            unit_price = round(random.uniform(10, 500), 2)

            # Weighted random status
            status = random.choices(
                [s[0] for s in self.ORDER_STATUSES],
                weights=[s[1] for s in self.ORDER_STATUSES],
            )[0]

            orders.append({
                "order_id": i,
                "customer_id": random.choice(customer_ids),
                "product_id": random.choice(product_ids),
                "quantity": quantity,
                "unit_price": unit_price,
                "total_amount": round(quantity * unit_price, 2),
                "order_date": order_date.isoformat(),
                "order_status": status,
                "shipping_address": self.faker.address().replace("\n", ", "),
            })

        return pd.DataFrame(orders)

    def generate_payments(
        self,
        order_ids: Optional[list[int]] = None,
        date: Optional[date] = None,
    ) -> pd.DataFrame:
        """
        Generate payment data.

        Args:
            order_ids: List of order IDs to generate payments for
            date: Specific date for payments

        Returns:
            DataFrame with payment data
        """
        if order_ids is None:
            order_ids = list(range(1, 1001))

        logger.info(f"Generating {len(order_ids)} payments")

        payments = []
        for i, order_id in enumerate(order_ids, start=1):
            # Generate payment date
            if date:
                payment_date = date
            else:
                payment_date = self.faker.date_between(
                    start_date="-30d",
                    end_date="today"
                )

            # Weighted random method
            method = random.choices(
                [m[0] for m in self.PAYMENT_METHODS],
                weights=[m[1] for m in self.PAYMENT_METHODS],
            )[0]

            # Weighted random status
            status = random.choices(
                [s[0] for s in self.PAYMENT_STATUSES],
                weights=[s[1] for s in self.PAYMENT_STATUSES],
            )[0]

            payments.append({
                "payment_id": i,
                "order_id": order_id,
                "payment_method": method,
                "payment_amount": round(random.uniform(10, 5000), 2),
                "payment_date": payment_date.isoformat(),
                "payment_status": status,
            })

        return pd.DataFrame(payments)

    def generate_all(
        self,
        output_dir: str | Path,
        n_customers: int = 1000,
        n_products: int = 500,
        n_orders: int = 10000,
        date_suffix: Optional[str] = None,
    ) -> dict[str, Path]:
        """
        Generate all datasets and save to CSV files.

        Args:
            output_dir: Directory to save CSV files
            n_customers: Number of customers
            n_products: Number of products
            n_orders: Number of orders
            date_suffix: Date suffix for filenames (default: today)

        Returns:
            Dictionary with entity names and file paths
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        if date_suffix is None:
            date_suffix = datetime.now().strftime("%Y-%m-%d")

        logger.info(f"Generating all datasets in {output_dir}")

        # Generate datasets
        customers_df = self.generate_customers(n=n_customers)
        products_df = self.generate_products(n=n_products)
        orders_df = self.generate_orders(
            n=n_orders,
            customer_ids=customers_df["customer_id"].tolist(),
            product_ids=products_df["product_id"].tolist(),
        )
        payments_df = self.generate_payments(
            order_ids=orders_df["order_id"].tolist(),
        )

        # Save to CSV
        files = {}
        for name, df in [
            ("customers", customers_df),
            ("products", products_df),
            ("orders", orders_df),
            ("payments", payments_df),
        ]:
            file_path = output_dir / f"{name}_{date_suffix}.csv"
            df.to_csv(file_path, index=False)
            files[name] = file_path
            logger.info(f"Saved {name}: {len(df)} rows to {file_path}")

        return files


def main():
    """CLI entry point for data generation."""
    import argparse

    parser = argparse.ArgumentParser(description="Generate e-commerce test data")
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./data/incoming",
        help="Output directory for CSV files",
    )
    parser.add_argument(
        "--customers",
        type=int,
        default=1000,
        help="Number of customers to generate",
    )
    parser.add_argument(
        "--products",
        type=int,
        default=500,
        help="Number of products to generate",
    )
    parser.add_argument(
        "--orders",
        type=int,
        default=10000,
        help="Number of orders to generate",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility",
    )

    args = parser.parse_args()

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Generate data
    generator = EcommerceDataGenerator(seed=args.seed)
    files = generator.generate_all(
        output_dir=args.output_dir,
        n_customers=args.customers,
        n_products=args.products,
        n_orders=args.orders,
    )

    print(f"\nGenerated files:")
    for name, path in files.items():
        print(f"  - {name}: {path}")


if __name__ == "__main__":
    main()
