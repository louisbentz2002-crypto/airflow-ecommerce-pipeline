"""
DAG: dag_ingest_ecommerce

Ingestion pipeline for e-commerce data.
- Extracts data from CSV files or generates synthetic data
- Loads raw data into PostgreSQL
- Runs data quality checks
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta
from pathlib import Path

from airflow import DAG
from airflow.decorators import task, task_group
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.postgres.operators.postgres import PostgresOperator

# Configure logging
logger = logging.getLogger(__name__)

# DAG default arguments
default_args = {
    "owner": "data-engineering",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 3,
    "retry_delay": timedelta(minutes=2),
    "retry_exponential_backoff": True,
    "max_retry_delay": timedelta(minutes=30),
    "execution_timeout": timedelta(minutes=30),
}

# Paths
DATA_DIR = Path("/opt/airflow/data/incoming")
SQL_DIR = Path("/opt/airflow/sql")

# Postgres connection
POSTGRES_CONN_ID = "postgres_dwh"


@task(retries=2)
def detect_new_files(ds: str, **kwargs) -> dict:
    """
    Detect new CSV files in the incoming directory.

    Args:
        ds: Execution date string (YYYY-MM-DD)

    Returns:
        Dictionary with file paths by entity type
    """
    import sys
    sys.path.insert(0, "/opt/airflow/src")
    from validators import EXPECTED_SCHEMAS

    logger.info(f"Scanning for files in {DATA_DIR} for date {ds}")

    files = {
        "orders": None,
        "customers": None,
        "products": None,
        "payments": None,
    }

    if DATA_DIR.exists():
        for file_path in DATA_DIR.glob("*.csv"):
            for entity in files:
                if entity in file_path.name.lower():
                    files[entity] = str(file_path)
                    logger.info(f"Found {entity} file: {file_path}")

    # Check which files are missing
    missing = [k for k, v in files.items() if v is None]
    if missing:
        logger.warning(f"Missing files for: {missing}")

    return {"files": files, "date": ds, "missing": missing}


@task(retries=2)
def validate_schema(file_info: dict) -> dict:
    """
    Validate schema of detected CSV files.

    Args:
        file_info: Dictionary from detect_new_files

    Returns:
        Validated file info with schema status
    """
    import sys
    sys.path.insert(0, "/opt/airflow/src")
    from validators import validate_csv_schema, EXPECTED_SCHEMAS

    files = file_info["files"]
    validation_results = {}

    for entity, file_path in files.items():
        if file_path is None:
            validation_results[entity] = {"valid": False, "error": "File not found"}
            continue

        try:
            is_valid, errors = validate_csv_schema(file_path, EXPECTED_SCHEMAS[entity])
            validation_results[entity] = {
                "valid": is_valid,
                "errors": errors if errors else None,
                "path": file_path,
            }
            logger.info(f"Schema validation for {entity}: {'PASSED' if is_valid else 'FAILED'}")
            if errors:
                logger.warning(f"Validation errors for {entity}: {errors}")
        except Exception as e:
            logger.error(f"Error validating {entity}: {e}")
            validation_results[entity] = {"valid": False, "error": str(e)}

    return {**file_info, "validation": validation_results}


@task(retries=2)
def generate_data_if_missing(validated_info: dict, ds: str, **kwargs) -> dict:
    """
    Generate synthetic data if CSV files are missing.

    Args:
        validated_info: Dictionary with validation results
        ds: Execution date

    Returns:
        Updated file info with generated data paths
    """
    import sys
    sys.path.insert(0, "/opt/airflow/src")
    from data_generator import EcommerceDataGenerator

    missing = validated_info.get("missing", [])

    if not missing:
        logger.info("All files present, no generation needed")
        return validated_info

    logger.info(f"Generating data for missing entities: {missing}")

    # Parse execution date
    exec_date = datetime.strptime(ds, "%Y-%m-%d").date()

    # Generate data
    generator = EcommerceDataGenerator(seed=42)

    # Ensure output directory exists
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    generated_files = {}

    if "customers" in missing:
        customers_df = generator.generate_customers(n=1000)
        customers_path = DATA_DIR / f"customers_{ds}.csv"
        customers_df.to_csv(customers_path, index=False)
        generated_files["customers"] = str(customers_path)
        logger.info(f"Generated {len(customers_df)} customers")

    if "products" in missing:
        products_df = generator.generate_products(n=500)
        products_path = DATA_DIR / f"products_{ds}.csv"
        products_df.to_csv(products_path, index=False)
        generated_files["products"] = str(products_path)
        logger.info(f"Generated {len(products_df)} products")

    if "orders" in missing:
        # Need customers and products first
        customers_df = generator.generate_customers(n=1000) if "customers" not in generated_files else None
        products_df = generator.generate_products(n=500) if "products" not in generated_files else None

        orders_df = generator.generate_orders(
            n=1000,
            customer_ids=list(range(1, 1001)),
            product_ids=list(range(1, 501)),
            date=exec_date,
        )
        orders_path = DATA_DIR / f"orders_{ds}.csv"
        orders_df.to_csv(orders_path, index=False)
        generated_files["orders"] = str(orders_path)
        logger.info(f"Generated {len(orders_df)} orders")

    if "payments" in missing:
        payments_df = generator.generate_payments(
            order_ids=list(range(1, 1001)),
            date=exec_date,
        )
        payments_path = DATA_DIR / f"payments_{ds}.csv"
        payments_df.to_csv(payments_path, index=False)
        generated_files["payments"] = str(payments_path)
        logger.info(f"Generated {len(payments_df)} payments")

    # Update file info
    updated_files = {**validated_info["files"], **generated_files}

    return {
        **validated_info,
        "files": updated_files,
        "generated": generated_files,
    }


@task(retries=3)
def load_raw_postgres(file_info: dict, ds: str, **kwargs) -> dict:
    """
    Load CSV data into raw PostgreSQL tables.
    Uses TRUNCATE + INSERT for idempotence.

    Args:
        file_info: Dictionary with file paths
        ds: Execution date

    Returns:
        Load statistics
    """
    import pandas as pd

    hook = PostgresHook(postgres_conn_id=POSTGRES_CONN_ID)
    conn = hook.get_conn()
    cursor = conn.cursor()

    files = file_info["files"]
    stats = {}

    for entity, file_path in files.items():
        if file_path is None:
            logger.warning(f"No file for {entity}, skipping")
            continue

        table_name = f"raw.raw_{entity}"
        logger.info(f"Loading {file_path} into {table_name}")

        try:
            # Read CSV
            df = pd.read_csv(file_path)

            # Add metadata columns
            df["_loaded_at"] = datetime.utcnow()
            df["_source_file"] = os.path.basename(file_path)
            df["_execution_date"] = ds

            # Truncate existing data for this date (idempotence)
            cursor.execute(f"""
                DELETE FROM {table_name}
                WHERE _execution_date = %s
            """, (ds,))

            # Insert data
            columns = list(df.columns)
            values_template = ", ".join(["%s"] * len(columns))
            insert_sql = f"""
                INSERT INTO {table_name} ({", ".join(columns)})
                VALUES ({values_template})
            """

            for _, row in df.iterrows():
                cursor.execute(insert_sql, tuple(row))

            conn.commit()
            stats[entity] = {"rows_loaded": len(df), "table": table_name}
            logger.info(f"Loaded {len(df)} rows into {table_name}")

        except Exception as e:
            conn.rollback()
            logger.error(f"Error loading {entity}: {e}")
            raise

    cursor.close()
    conn.close()

    return {"load_stats": stats, "date": ds}


@task(retries=2)
def dq_raw_checks(load_stats: dict, ds: str, **kwargs) -> dict:
    """
    Run data quality checks on raw tables.

    Checks:
    - Row counts > 0
    - Primary keys not null
    - Dates within valid range
    """
    import sys
    sys.path.insert(0, "/opt/airflow/src")
    from utils import run_dq_check

    hook = PostgresHook(postgres_conn_id=POSTGRES_CONN_ID)

    checks = []

    # Check 1: Row counts
    for entity in ["orders", "customers", "products", "payments"]:
        table = f"raw.raw_{entity}"
        result = run_dq_check(
            hook=hook,
            check_name=f"count_check_{entity}",
            sql=f"SELECT COUNT(*) > 0 as passed FROM {table} WHERE _execution_date = '{ds}'",
        )
        checks.append(result)

    # Check 2: Null primary keys (orders)
    result = run_dq_check(
        hook=hook,
        check_name="null_pk_orders",
        sql=f"""
            SELECT COUNT(*) = 0 as passed
            FROM raw.raw_orders
            WHERE order_id IS NULL AND _execution_date = '{ds}'
        """,
    )
    checks.append(result)

    # Check 3: Valid dates
    result = run_dq_check(
        hook=hook,
        check_name="valid_order_dates",
        sql=f"""
            SELECT COUNT(*) = 0 as passed
            FROM raw.raw_orders
            WHERE order_date > CURRENT_DATE + INTERVAL '1 day'
            OR order_date < '2020-01-01'
        """,
    )
    checks.append(result)

    # Summarize results
    passed = sum(1 for c in checks if c["passed"])
    failed = len(checks) - passed

    logger.info(f"DQ Checks: {passed}/{len(checks)} passed")

    if failed > 0:
        failed_checks = [c for c in checks if not c["passed"]]
        logger.error(f"Failed checks: {failed_checks}")
        raise ValueError(f"Data quality checks failed: {failed_checks}")

    return {"checks": checks, "passed": passed, "failed": failed}


# Define TaskGroup for extraction
@task_group(group_id="extract")
def extract_group(ds: str):
    """TaskGroup for extraction tasks."""
    files = detect_new_files(ds=ds)
    validated = validate_schema(files)
    generated = generate_data_if_missing(validated, ds=ds)
    return generated


# DAG Definition
with DAG(
    dag_id="dag_ingest_ecommerce",
    default_args=default_args,
    description="Ingest e-commerce data from CSV to PostgreSQL raw layer",
    schedule_interval="@daily",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["ecommerce", "ingestion", "raw"],
    doc_md=__doc__,
    max_active_runs=1,
    # SLA
    sla_miss_callback=None,
) as dag:

    # Extract TaskGroup
    extracted = extract_group(ds="{{ ds }}")

    # Load to raw
    loaded = load_raw_postgres(extracted, ds="{{ ds }}")

    # Data quality checks
    dq_results = dq_raw_checks(loaded, ds="{{ ds }}")

    # Dependencies are implicit via TaskFlow
