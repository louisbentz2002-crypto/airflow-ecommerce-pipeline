"""
Airflow E-Commerce Pipeline - Source Package

This package contains utility modules for:
- Data generation (Faker)
- Schema validation
- Helper utilities
"""

__version__ = "1.0.0"
__author__ = "Data Engineering Team"
