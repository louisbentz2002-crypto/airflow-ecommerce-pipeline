-- ============================================
-- MART: Customer Lifetime Value (LTV)
-- ============================================
-- Calculate LTV metrics per customer
-- Idempotent: TRUNCATE + INSERT

-- Truncate and rebuild
TRUNCATE TABLE mart.customer_ltv;

-- Insert customer LTV data
INSERT INTO mart.customer_ltv (
    customer_id,
    full_name,
    email,
    first_order_date,
    last_order_date,
    total_orders,
    total_quantity,
    lifetime_value,
    average_order_value,
    customer_tenure_days,
    _updated_at
)
WITH customer_orders AS (
    SELECT
        o.customer_id,
        c.full_name,
        c.email,
        MIN(o.order_date) AS first_order_date,
        MAX(o.order_date) AS last_order_date,
        COUNT(DISTINCT o.order_id) AS total_orders,
        SUM(o.quantity) AS total_quantity,
        SUM(o.total_amount) AS lifetime_value
    FROM staging.stg_orders o
    INNER JOIN staging.stg_customers c ON o.customer_id = c.customer_id
    WHERE
        o.order_status IN ('COMPLETED', 'DELIVERED', 'SHIPPED', 'PAID')
    GROUP BY
        o.customer_id,
        c.full_name,
        c.email
)
SELECT
    customer_id,
    full_name,
    email,
    first_order_date,
    last_order_date,
    total_orders,
    total_quantity,
    lifetime_value,
    ROUND(
        lifetime_value::DECIMAL / NULLIF(total_orders, 0),
        2
    ) AS average_order_value,
    -- Days since first order
    EXTRACT(DAY FROM (last_order_date - first_order_date))::INTEGER AS customer_tenure_days,
    CURRENT_TIMESTAMP AS _updated_at
FROM customer_orders
ORDER BY lifetime_value DESC
;

-- Log summary
DO $$
DECLARE
    v_total_customers INTEGER;
    v_avg_ltv DECIMAL;
    v_top_customer VARCHAR;
    v_top_ltv DECIMAL;
BEGIN
    SELECT
        COUNT(*),
        ROUND(AVG(lifetime_value), 2)
    INTO v_total_customers, v_avg_ltv
    FROM mart.customer_ltv;

    SELECT full_name, lifetime_value
    INTO v_top_customer, v_top_ltv
    FROM mart.customer_ltv
    ORDER BY lifetime_value DESC
    LIMIT 1;

    RAISE NOTICE 'Customer LTV Summary: % customers, avg LTV: %, top customer: % with %',
        v_total_customers, v_avg_ltv, v_top_customer, v_top_ltv;
END $$;
