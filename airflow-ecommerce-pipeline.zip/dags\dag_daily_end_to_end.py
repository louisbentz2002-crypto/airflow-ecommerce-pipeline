"""
DAG: dag_daily_end_to_end

Daily orchestration pipeline that triggers:
1. Ingestion DAG (dag_ingest_ecommerce)
2. Transformation DAG (dag_transform_ecommerce)

Provides a single entry point for the full ELT pipeline.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from airflow import DAG
from airflow.decorators import task
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.sensors.external_task import ExternalTaskSensor

# Configure logging
logger = logging.getLogger(__name__)

# DAG default arguments
default_args = {
    "owner": "data-engineering",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
    "retry_exponential_backoff": True,
    "max_retry_delay": timedelta(minutes=30),
    "execution_timeout": timedelta(hours=2),
}


@task
def start_pipeline(**kwargs) -> dict:
    """
    Initialize the daily pipeline run.

    Logs metadata and validates execution context.
    """
    execution_date = kwargs.get("ds")
    run_id = kwargs.get("run_id")

    logger.info(f"Starting daily e-commerce pipeline")
    logger.info(f"Execution date: {execution_date}")
    logger.info(f"Run ID: {run_id}")

    return {
        "execution_date": execution_date,
        "run_id": run_id,
        "started_at": datetime.utcnow().isoformat(),
    }


@task
def end_pipeline(start_info: dict, **kwargs) -> dict:
    """
    Finalize the daily pipeline run.

    Logs completion metrics and summary.
    """
    execution_date = kwargs.get("ds")

    logger.info(f"Daily e-commerce pipeline completed successfully")
    logger.info(f"Execution date: {execution_date}")
    logger.info(f"Pipeline started at: {start_info.get('started_at')}")
    logger.info(f"Pipeline ended at: {datetime.utcnow().isoformat()}")

    return {
        **start_info,
        "ended_at": datetime.utcnow().isoformat(),
        "status": "success",
    }


# DAG Definition
with DAG(
    dag_id="dag_daily_end_to_end",
    default_args=default_args,
    description="Daily orchestration of full e-commerce ELT pipeline",
    schedule_interval="0 6 * * *",  # 6:00 UTC daily
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["ecommerce", "orchestration", "daily"],
    doc_md=__doc__,
    max_active_runs=1,
) as dag:

    # Start task
    pipeline_start = start_pipeline()

    # Trigger ingestion DAG
    trigger_ingest = TriggerDagRunOperator(
        task_id="trigger_ingest",
        trigger_dag_id="dag_ingest_ecommerce",
        execution_date="{{ ds }}",
        reset_dag_run=True,  # Allow re-running
        wait_for_completion=True,
        poke_interval=30,
        allowed_states=["success"],
        failed_states=["failed"],
    )

    # Trigger transformation DAG
    trigger_transform = TriggerDagRunOperator(
        task_id="trigger_transform",
        trigger_dag_id="dag_transform_ecommerce",
        execution_date="{{ ds }}",
        reset_dag_run=True,
        wait_for_completion=True,
        poke_interval=30,
        allowed_states=["success"],
        failed_states=["failed"],
    )

    # End task
    pipeline_end = end_pipeline(pipeline_start)

    # Define dependencies
    pipeline_start >> trigger_ingest >> trigger_transform >> pipeline_end
